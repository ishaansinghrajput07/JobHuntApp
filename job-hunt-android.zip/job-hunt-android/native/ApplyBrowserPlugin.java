package com.jobhunt.app;

import android.content.Intent;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "ApplyBrowser")
public class ApplyBrowserPlugin extends Plugin {
    @PluginMethod
    public void open(PluginCall call) {
        String url = call.getString("url");
        if (url == null) { call.reject("url required"); return; }
        Intent i = new Intent(getContext(), ApplyActivity.class);
        i.putExtra("url", url);
        i.putExtra("profile", call.getString("profile", "{}"));
        getActivity().startActivity(i);
        call.resolve();
    }
}
