(function () {
  var P = __PROFILE__;
  if (document.getElementById('jh-btn')) return;
  function setVal(el, v) {
    var d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    d.set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function labelOf(el) {
    var t = (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.name || '') + ' ' + (el.id || '');
    if (el.id) { var l = document.querySelector('label[for="' + el.id + '"]'); if (l) t += ' ' + l.innerText; }
    var p = el.closest('label'); if (p) t += ' ' + p.innerText;
    return t.toLowerCase();
  }
  function fill() {
    var n = 0;
    document.querySelectorAll('input:not([type=hidden]):not([type=file]):not([type=checkbox]):not([type=radio]),textarea').forEach(function (el) {
      if (el.value) return;
      var t = labelOf(el), v = null;
      if (/e-?mail/.test(t)) v = P.email;
      else if (/phone|mobile/.test(t)) v = P.phone;
      else if (/notice/.test(t)) v = P.notice;
      else if (/current.*(ctc|salary)/.test(t)) v = P.ctc;
      else if (/expected.*(ctc|salary)/.test(t)) v = P.ectc;
      else if (/experience|years/.test(t)) v = P.exp;
      else if (/city|location/.test(t)) v = P.city;
      else if (/name/.test(t)) v = P.name;
      else if (el.tagName === 'TEXTAREA' && /cover|why|about|describe/.test(t)) v = P.cover;
      if (v) { setVal(el, v); n++; }
    });
    return n;
  }
  function clickApply() {
    var ok = /^(apply|easy apply|apply now|next|continue)$/i;
    var b = [].slice.call(document.querySelectorAll('button,a,[role=button]')).filter(function (x) {
      return ok.test((x.innerText || '').trim());
    })[0];
    if (b) b.click();
    return !!b;
  }
  var btn = document.createElement('button');
  btn.id = 'jh-btn';
  btn.textContent = 'Auto-fill & Apply';
  btn.style.cssText = 'position:fixed;right:14px;bottom:20px;z-index:2147483647;background:#5b4bdb;color:#fff;border:0;border-radius:24px;padding:14px 18px;font:600 15px sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.35)';
  btn.onclick = function () {
    var f1 = fill(); var c = clickApply();
    setTimeout(function () { var f2 = fill(); btn.textContent = 'Filled ' + (f1 + f2) + ' fields' + (c ? ', Apply tapped' : ''); }, 1800);
  };
  document.body.appendChild(btn);
})();
