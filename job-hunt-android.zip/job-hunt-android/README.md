# Job Hunt (Android)

1. Install Node 18+ and Android Studio.
2. Run ./setup.sh (creates the android/ project and adds the apply browser).
3. AI features: deploy server/server.js over https (set ANTHROPIC_API_KEY), put its URL in
   www/index.html at window.JH_API, then run: npx cap sync android
4. npx cap open android, then Build > Build APK(s).

Apply flow: One-tap apply opens the job page in an in-app browser. Log in once (cookies persist),
then tap the purple "Auto-fill & Apply" button. You review and submit.
Field matching is by label text and is a best guess; test on one real Naukri job and adjust native/autofill.js.

## Phone OTP (Connected Accounts)
server/server.js verifies your mobile number by SMS using Twilio Verify. Set TWILIO_SID, TWILIO_TOKEN and
TWILIO_VERIFY_SID, deploy over https, then set window.JH_OTP_API in www/index.html to https://your-server/otp
and run: npx cap sync android. Without it, Connect opens the job site's own login page instead.

## In-app job feed
GET /jobs on server/server.js returns jobs from the Adzuna India API (free keys at developer.adzuna.com;
set ADZUNA_ID and ADZUNA_KEY). Put https://your-server/jobs in window.JH_JOBS_API in www/index.html, then
run: npx cap sync android. The Jobs tab then loads jobs inside the app and re-queries when you change
Posted, Location, Work mode, Salary or Sort. Adzuna aggregates many job boards; it does not include
LinkedIn or Naukri listings, and scraping those sites is against their terms.

## Google sign-in (Connected Accounts)
1. Google Cloud Console > APIs & Services > Credentials. Create an OAuth client of type Web application
   and copy its client ID into capacitor.config.json (plugins.GoogleAuth.serverClientId).
2. Create a second OAuth client of type Android with package name com.jobhunt.app and the SHA-1 of your
   signing key (run: cd android && ./gradlew signingReport). Add your Google account as a test user on the
   OAuth consent screen while the app is in testing.
3. Run npx cap sync android and rebuild.
Plugin: @codetrix-studio/capacitor-google-auth (community plugin). If npm reports a Capacitor version
conflict, keep --legacy-peer-deps, or swap in another Capacitor Google sign-in plugin; the app only calls
GoogleAuth.initialize and GoogleAuth.signIn.
Google blocks its own sign-in inside embedded web views, so Naukri, LinkedIn, Indeed and foundit must be
logged into with their own email or mobile login in the apply browser.

## Adzuna keys (pre-configured)
The Adzuna App ID and Key are preset in www/index.html (window.JH_ADZ_ID / window.JH_ADZ_KEY), so the Jobs tab
loads India listings directly from the device with no server. You can still override them in Manage > Job Feed.
To use the server route instead, run: ADZUNA_ID=e5d9bce5 ADZUNA_KEY=<key> node server/server.js and set window.JH_JOBS_API.
Note: keys inside an APK can be extracted. Fine for personal use; do not distribute the APK publicly.

## Deploy the server (Render, free tier)
1. Push this folder to a private GitHub repo.
2. render.com > New > Web Service > pick the repo. Root directory: server. Build: (none). Start: node server.js.
3. Environment variables: ANTHROPIC_API_KEY (your key), APP_TOKEN (any long random string), optional ADZUNA_ID / ADZUNA_KEY.
4. After deploy you get https://your-app.onrender.com. In www/index.html set window.JH_API to that URL,
   window.JH_TOKEN to the same APP_TOKEN, and (optional) window.JH_JOBS_API to https://your-app.onrender.com/jobs.
5. npx cap sync android, rebuild the APK.
Free Render services sleep when idle, so the first AI reply after a pause can take ~30 seconds.
