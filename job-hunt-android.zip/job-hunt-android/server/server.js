// Job Hunt server: AI proxy (/) and phone OTP verification (/otp).
// Run: ANTHROPIC_API_KEY=... TWILIO_SID=... TWILIO_TOKEN=... TWILIO_VERIFY_SID=... node server.js
const http = require('http');
const KEY = process.env.ANTHROPIC_API_KEY;
const SID = process.env.TWILIO_SID, TOK = process.env.TWILIO_TOKEN, VS = process.env.TWILIO_VERIFY_SID;

async function tw(path, params) {
  const r = await fetch('https://verify.twilio.com/v2/Services/' + VS + '/' + path, {
    method: 'POST',
    headers: { Authorization: 'Basic ' + Buffer.from(SID + ':' + TOK).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params)
  });
  return r.json();
}
const phone = id => { const d = id.replace(/[^\d+]/g, ''); return d.startsWith('+') ? d : '+91' + d.slice(-10); };


// Job feed from the Adzuna India API (free keys at developer.adzuna.com): ADZUNA_ID, ADZUNA_KEY
const AID = process.env.ADZUNA_ID, AKEY = process.env.ADZUNA_KEY;
const SKILLS = ['Angular', 'React', 'TypeScript', 'JavaScript', 'Java', 'Node.js', 'Python', 'AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes', 'Terraform', 'Kafka', 'Microservices', 'SQL', 'CI/CD', 'DevOps', 'Agile', 'Git'];
function expOf(t) {
  const m = t.match(/(\d{1,2})\s*(?:-|–|to)\s*(\d{1,2})\s*\+?\s*(?:years|yrs)/i) || t.match(/(\d{1,2})\s*\+?\s*(?:years|yrs)/i);
  return m ? (m[2] ? m[1] + '–' + m[2] + ' yrs' : m[1] + '+ yrs') : '';
}
async function adzuna(q, city) {
  const u = new URL('https://api.adzuna.com/v1/api/jobs/in/search/1');
  const p = { app_id: AID, app_key: AKEY, results_per_page: '20', what: q.role + (q.wm && q.wm !== 'Any' ? ' ' + q.wm : ''), where: city, sort_by: q.sort === 'D' ? 'date' : 'relevance' };
  if (q.days) p.max_days_old = q.days;
  if (q.smin) p.salary_min = q.smin;
  u.search = new URLSearchParams(p);
  const d = await (await fetch(u)).json();
  return (d.results || []).map(j => {
    const text = j.title + ' ' + (j.description || '');
    return {
      title: j.title, company: (j.company || {}).display_name || '', location: (j.location || {}).display_name || '',
      desc: j.description || '', url: j.redirect_url, ts: Date.parse(j.created) || Date.now(), exp: expOf(text),
      tags: SKILLS.filter(s => text.toLowerCase().includes(s.toLowerCase())).slice(0, 5),
      salary: j.salary_min ? '₹' + Math.round(j.salary_min / 1e5) + (j.salary_max > j.salary_min ? '–' + Math.round(j.salary_max / 1e5) : '') + 'L' : ''
    };
  });
}

http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-app-token');
  res.setHeader('Content-Type', 'application/json');
  if (req.method === 'OPTIONS') { res.end(); return; }
  if (req.method === 'GET' && req.url.startsWith('/jobs')) {
    try {
      if (!AID || !AKEY) { res.end('[]'); return; }
      const q = Object.fromEntries(new URL(req.url, 'http://x').searchParams);
      const cities = (q.city || 'India').split('|').slice(0, 3);
      const all = (await Promise.all(cities.map(c => adzuna(q, c)))).flat();
      const seen = new Set();
      res.end(JSON.stringify(all.filter(j => j.url && !seen.has(j.url) && seen.add(j.url))));
    } catch (e) { res.statusCode = 500; res.end('[]'); }
    return;
  }
  if (req.method !== 'POST') { res.statusCode = 404; res.end(); return; }
  let body = ''; for await (const c of req) body += c;
  try {
    const data = JSON.parse(body);
    if (req.url.startsWith('/otp')) {
      if (!SID || !TOK || !VS) { res.end(JSON.stringify({ ok: false, error: 'OTP service is not configured on the server.' })); return; }
      if ((data.id || '').includes('@')) { res.end(JSON.stringify({ ok: false, error: 'Use your mobile number for OTP.' })); return; }
      if (data.action === 'send') {
        const d = await tw('Verifications', { To: phone(data.id), Channel: 'sms' });
        res.end(JSON.stringify({ ok: d.status === 'pending', error: d.message }));
      } else {
        const d = await tw('VerificationCheck', { To: phone(data.id), Code: data.otp });
        res.end(JSON.stringify({ ok: d.status === 'approved', error: 'That OTP did not match.' }));
      }
      return;
    }
    if (process.env.APP_TOKEN && req.headers['x-app-token'] !== process.env.APP_TOKEN) { res.statusCode = 401; res.end(JSON.stringify({ text: 'Unauthorized' })); return; }
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-sonnet-5-5', max_tokens: 1500, messages: data.messages })
    });
    const d = await r.json();
    res.end(JSON.stringify({ text: (d.content || []).map(b => b.text || '').join('') }));
  } catch (e) { res.statusCode = 500; res.end(JSON.stringify({ text: 'Server error', ok: false })); }
}).listen(process.env.PORT || 8787);
