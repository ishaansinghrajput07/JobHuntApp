#!/bin/bash
set -e
npm install
npm install @codetrix-studio/capacitor-google-auth --legacy-peer-deps
npx cap add android
P=android/app/src/main/java/com/jobhunt/app
cp native/*.java $P/
mkdir -p android/app/src/main/assets
cp native/autofill.js android/app/src/main/assets/
sed -i 's#</application>#    <activity android:name=".ApplyActivity" android:exported="false" />\n    </application>#' android/app/src/main/AndroidManifest.xml
npx cap sync android
echo "Done. Next: npx cap open android, then Build > Build APK(s)"
